const keys =
{
    sendgrid_key:'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'
}
module.exports = keys;